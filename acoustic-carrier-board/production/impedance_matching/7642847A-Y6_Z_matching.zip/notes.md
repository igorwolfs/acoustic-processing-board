# ULPI
- Make sure to put the USB.CLK trace far enough from the USB.NXT trace. At the moment they are too close together.
